using System;
using System.IO;
using WMVLib;

class MovieMaker
{
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main(string[] args)
	{
		MovieMaker movie = null;
            
		//
		// Instantiate the host and run it         
		//
		try 
		{
			movie = new MovieMaker();
			movie.Run(args);
		}
		catch (Exception ex)
		{
			Console.Out.WriteLine( ex.Message );                
			Console.Out.WriteLine( ex.StackTrace );                
		}       
	}

	/// <summary>
	/// Runs the specified args.
	/// </summary>
	/// <param name="args">Args.</param>
	public void Run(string [] args)
	{
		string fileFilter = "*.jpg";
		string inputDirectory = ".";
		string prxFileName = String.Empty;
		string outputFileName = String.Empty;

		if(args.Length == 1 && args[0] == "/?")
		{
			Console.WriteLine("Usage: MovieMaker.exe profile_file_name output_file_name [input filter ex: *.bmp] [input directory]");
			System.Environment.Exit(0);
		}
		else if(args.Length > 1)
		{
			prxFileName = args[0];
			outputFileName = args[1];
				
			if(args.Length > 2)
			{
				fileFilter = args[2];
			}
			if(args.Length > 3)
			{
				inputDirectory = args[3];
			}
		}
		else
		{				
			Console.Write("Enter .PRX file Name: ");
			prxFileName = Console.ReadLine();

			Console.Write("Enter .WMV file Name: ");
			outputFileName = Console.ReadLine();

			Console.Write("Press Any Key convert");
			Console.Read();
		}

		// Find the input files
		string [] files = Directory.GetFiles(inputDirectory, fileFilter);

		// Throw exceptions if we have any missing info
		if(files.Length < 1)
			throw new Exception("No JPEG files found!");
		if(outputFileName.Length == 0)
			throw new ArgumentException("No output file specified!");
		if(prxFileName.Length == 0)
			throw new ArgumentException("No profile file specified!");

		// Finally save the video
		WMVService.SaveVideo(outputFileName, prxFileName, files);

		Console.WriteLine();
		Console.WriteLine(String.Format("{0} frames written to file {1}", files.Length, outputFileName));			
	}
}
