﻿
namespace System.Runtime.CompilerServices
{
    class CompilerGeneratedAttribute : Attribute
    {
    }
}
