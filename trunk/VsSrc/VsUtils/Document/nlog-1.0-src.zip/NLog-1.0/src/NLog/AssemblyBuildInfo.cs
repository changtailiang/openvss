// do not modify this file. It will be automatically regenerated
// based on the version number saved in 'NLog.version'
using System.Reflection;
[assembly: AssemblyVersion("1.0.0.505")]
