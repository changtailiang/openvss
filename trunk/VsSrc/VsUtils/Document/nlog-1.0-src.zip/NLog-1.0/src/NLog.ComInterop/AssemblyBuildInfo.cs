// do not modify this file. It will be automatically regenerated
// based on the version number saved in src/NLog.ComInterop/AssemblyBuildInfo.cs is changed.
using System.Reflection;
[assembly: AssemblyVersion("1.0.0.505")]
