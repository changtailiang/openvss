using System;
using System.Globalization;

using NLog;

class MyClass {
    static Logger logger = LogManager.GetLogger("MyClass");

    // other class members go here

}
